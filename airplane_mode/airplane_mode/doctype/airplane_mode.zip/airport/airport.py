# Copyright (c) 2024, asha rawat and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class Airport(Document):
	pass
